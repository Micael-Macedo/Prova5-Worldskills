<?php
	echo $typeObj->getViewContent();
?>