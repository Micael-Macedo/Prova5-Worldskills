<?php
	echo $this->getViewContent();
