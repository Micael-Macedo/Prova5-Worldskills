<div class="ycf-bootstrap-wrapper ycf-pro-wrapper">
	<p class="ypm-upgrade-pro">
		Want to upgrade to <b>PRO version</b>?
	</p>
    <button class="ycd-upgrade-button-red">
        <b class="h2">Upgrade</b><br><span class="h5">to PRO version</span>
    </button>
</div>
