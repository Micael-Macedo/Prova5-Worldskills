<?php
self::addDefine('YCD_PKG_VERSION', YCD_FREE_VERSION);